
# BSS Hive Planner (50 slots) — static site

This repository contains a single-page app for planning a Bee Swarm Simulator hive:
- 50-slot hive grid with drag & drop.
- Gear (masks/items) & field boosts.
- Honey/hour calculator (bottleneck = min(pollen/s, convert/s)).
- **Custom icons**: bulk-upload images or set URLs; saved in localStorage.
- Export/Import JSON including icons.

## How to publish with GitHub Pages
1. Commit this repository to `main` (root has `index.html`).
2. **Nothing else required** — a GitHub Actions workflow will auto-deploy to Pages.
3. Open the latest workflow run → `Deploy to GitHub Pages` → find the URL.

If you prefer the classic "Deploy from branch", you can switch in Settings → Pages.
